<?php
// Text
$_['cookie_consent_text'] = 'We use cookies to customize ads and improve your experience on the site. By continuing to browse, you agree with our <a href="index.php?route=information/information&information_id=3" target="_self"><i class="fa fa-exclamation-circle"></i> Policy Privacy Policy.</a>';
$_['cookie_consent_got_it'] = 'Continue and Close';