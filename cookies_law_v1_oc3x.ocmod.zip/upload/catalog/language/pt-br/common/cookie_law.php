<?php

// Text
$_['cookie_consent_text'] = 'A gente usa cookies para personalizar anúncios e melhorar a sua experiência no site. Ao continuar navegando, você concorda com a nossa <a href="index.php?route=information/information&information_id=3" target="_self"><i class="fa fa-exclamation-circle"></i> Política de Privacidade.</a>';
$_['cookie_consent_got_it'] = 'Continuar e fechar';